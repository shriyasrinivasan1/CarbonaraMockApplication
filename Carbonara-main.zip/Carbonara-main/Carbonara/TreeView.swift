//
//  TreeView.swift
//  CoreMotionPost
//
//  Created by sooraj on 2/27/21.
//  Copyright © 2021 kamwysoc. All rights reserved.
//

import UIKit
    
class TreeView: UIViewController {
    override func viewDidLoad() {
        print("First Controller Loaded")
        
    }
    
}
