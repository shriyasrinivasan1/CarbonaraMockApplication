//
//  ViewController.swift
//  Carbonara
//
//  Created by Shriya Srinivasan on 2/27/21.
//

import UIKit

class ViewController: UIViewController {
    // MARK: Properties
    
    @IBOutlet weak var funFacts: UIButton!
    @IBOutlet weak var calTracker: UIButton!
    
    @IBOutlet weak var pedometer: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // MARK: Actions
    @IBAction func funFactsAction(_ sender: Any) {
        
    }
}

