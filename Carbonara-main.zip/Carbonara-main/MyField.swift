import UIKit
import CoreMotion
import Dispatch


class MyField: UIViewController {

    
    override func viewDidLoad() {
        print("Loading")
        
        
    }
}
